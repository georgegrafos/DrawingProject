package ca.qc.johnabbott.cs603.Tools;

public enum ToolName { NONE, LINE, RECTANGLE, SQUARE, ELLIPSE, CIRCLE }